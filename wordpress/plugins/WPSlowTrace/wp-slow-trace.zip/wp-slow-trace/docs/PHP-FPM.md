# Optional PHP-FPM slowlog integration (server administrator)

WP Slow Trace does **not** modify PHP-FPM configuration or ingest slowlogs automatically. Enable this independently in the correct PHP-FPM pool (for example `/etc/php-fpm.d/example.conf`, depending on OS/panel):

```ini
request_slowlog_timeout = 2s
slowlog = /var/log/php-fpm/wordpress-slow.log
request_slowlog_trace_depth = 30
```

Create a protected, writable log destination using the pool's service permissions. Validate with `php-fpm -tt` (binary/service names vary) and reload the relevant php-fpm service after checking the configuration. Protect the slowlog from public web access and rotate it with logrotate. Do **not** expose it via WordPress or the web root. Consider `request_terminate_timeout` separately and cautiously; do not enable termination merely to trace requests. FPM slowlogs can show PHP stack frames during a long request, including time spent waiting on database or filesystem operations, but cannot diagnose all kernel D-state stalls. Correlate using UTC timestamps, request paths, and pool logs; this release has no automated correlation or slowlog viewer.
