<?php
/**
 * Plugin Name: WP Slow Trace Bootstrap
 * Description: Enables query collection before normal plugins load. Requires WP Slow Trace.
 */
if (!defined('ABSPATH')) exit;
// WordPress loads MU plugins after wpdb initialization. This captures subsequent queries,
// not the earliest bootstrap queries. The main plugin checks the option before persisting.
if (defined('SAVEQUERIES') && SAVEQUERIES !== true) return;
if (!defined('SAVEQUERIES')) define('SAVEQUERIES', true);
$GLOBALS['wst_request_started'] = isset($_SERVER['REQUEST_TIME_FLOAT']) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : microtime(true);
