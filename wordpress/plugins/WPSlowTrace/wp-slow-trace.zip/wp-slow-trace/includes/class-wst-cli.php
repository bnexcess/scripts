<?php
if (!defined('ABSPATH') || !defined('WP_CLI') || !WP_CLI) return;
/** Inspect recorded WP Slow Trace diagnostics. All timestamps are UTC. */
final class WST_CLI {
 private static function table() { global $wpdb; return $wpdb->prefix.'wst_traces'; }
 private static function options($args) {
  $top=isset($args['top'])?(int)$args['top']:20;
  if ($top<1 || $top>500) WP_CLI::error('--top must be between 1 and 500.');
  $since=isset($args['since'])?(string)$args['since']:'24h';
  if (!preg_match('/^([1-9][0-9]{0,5})([hdw])$/',$since,$m)) WP_CLI::error('--since must be a positive duration such as 1h, 24h, or 7d.');
  $unit=array('h'=>3600,'d'=>86400,'w'=>604800);
  $seconds=(int)$m[1]*$unit[$m[2]];
  if ($seconds>365*86400) WP_CLI::error('--since cannot exceed 365 days.');
  $format=isset($args['format'])?(string)$args['format']:'table';
  if (!in_array($format,array('table','json','csv'),true)) WP_CLI::error('--format must be table, json, or csv.');
  return array($top,gmdate('Y-m-d H:i:s',time()-$seconds),$format,$since);
 }
 private static function rows($cutoff,$limit=0,$order='duration_ms DESC') {
  global $wpdb; $table=self::table();
  // $order is exclusively supplied by internal hard-coded callers.
  $sql=$wpdb->prepare("SELECT * FROM $table WHERE created_at >= %s ORDER BY $order",$cutoff);
  if ($limit) $sql.=$wpdb->prepare(' LIMIT %d',$limit);
  return (array)$wpdb->get_results($sql,ARRAY_A);
 }
 private static function payload($r) { $v=json_decode($r['queries'],true);return is_array($v)?$v:array(); }
 private static function output($items,$fields,$format) {
  if ($format==='json') { WP_CLI::line(wp_json_encode($items,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));return; }
  if (!$items) { WP_CLI::line('No matching stored traces.');return; }
  WP_CLI\Utils\format_items($format,$items,$fields);
 }
 /** Show plugin configuration and stored trace counts. */
 public function status($pos,$assoc) {
  global $wpdb; $s=WST::settings();$t=self::table();
  $exists=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($t)))===$t;
  $count=$exists?(int)$wpdb->get_var("SELECT COUNT(*) FROM $t"):0;
  $last=$exists?$wpdb->get_var("SELECT MAX(created_at) FROM $t"):null;
  $items=array(
   array('setting'=>'enabled','value'=>empty($s['enabled'])?'no':'yes'),
   array('setting'=>'php_threshold_ms','value'=>(int)$s['php_ms']),
   array('setting'=>'sql_threshold_ms','value'=>(int)$s['sql_ms']),
   array('setting'=>'retention_days','value'=>(int)$s['retention']),
   array('setting'=>'mode','value'=>$s['mode']),
   array('setting'=>'stored_traces','value'=>$count),
   array('setting'=>'last_trace_utc','value'=>$last?:'none'),
   array('setting'=>'savequeries','value'=>defined('SAVEQUERIES')&&SAVEQUERIES?'enabled in this CLI process':'disabled in this CLI process'),
  );
  $fmt=isset($assoc['format'])?$assoc['format']:'table';
  if (!in_array($fmt,array('table','json','csv'),true)) WP_CLI::error('Invalid format.');
  self::output($items,array('setting','value'),$fmt);
 }
 /** Summarize slow requests and SQL captured in stored traces.
  *
  * ## OPTIONS
  * [--since=<duration>] : Lookback window, e.g. 24h or 7d.
  * [--top=<number>] : Maximum rows in each top section (1-500).
  * [--format=<format>] : table, json, or csv (JSON recommended for complete report).
  */
 public function report($pos,$assoc) {
  list($top,$cutoff,$format,$since)=self::options($assoc);
  $rows=self::rows($cutoff);$sql=array();$hooks=array();$total=0;$peak=0;$available=0;
  foreach ($rows as $r) {
   $total+=(int)$r['duration_ms'];$peak=max($peak,(int)$r['peak_bytes']);
   $p=self::payload($r);if (!empty($p['available'])) $available++;
   foreach ((array)($p['items']??array()) as $q) $sql[]=array('ms'=>(float)($q['ms']??0),'route'=>$r['route'],'sql'=>(string)($q['sql']??''),'caller'=>(string)($q['caller']??''));
   foreach ((array)($p['php_checkpoints']??array()) as $h) $hooks[]=array('hook'=>(string)($h['hook']??''),'elapsed_ms'=>(float)($h['elapsed_ms']??0),'route'=>$r['route']);
  }
  usort($rows,function($a,$b){return (int)$b['duration_ms']<=>(int)$a['duration_ms'];});
  usort($sql,function($a,$b){return $b['ms']<=>$a['ms'];});
  $summary=array('since'=>$since,'requests'=>count($rows),'avg_php_ms'=>count($rows)?round($total/count($rows),2):0,'max_php_ms'=>$rows?(int)$rows[0]['duration_ms']:0,'peak_memory_mb'=>round($peak/1048576,2),'requests_with_sql_collection'=>$available,'stored_slow_sql_entries'=>count($sql),'note'=>'SQL entries are capped per request; hook checkpoints are elapsed milestones, not per-hook durations.');
  $php=array_map(function($r){return self::brief($r);},array_slice($rows,0,$top));
  if ($format==='json') { WP_CLI::line(wp_json_encode(array('summary'=>$summary,'top_php'=>$php,'top_sql'=>array_slice($sql,0,$top)),JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));return; }
  WP_CLI::line('WP Slow Trace report (UTC)');
  foreach ($summary as $k=>$v) WP_CLI::line($k.': '.$v);
  WP_CLI::line("\nTop PHP requests:");self::output($php,array('id','created_at','duration_ms','sql_total_ms','route','request_type'),$format);
  WP_CLI::line("\nTop stored slow SQL queries:");self::output(array_slice($sql,0,$top),array('ms','route','sql','caller'),$format);
 }
 private static function brief($r) { return array('id'=>(int)$r['id'],'created_at'=>$r['created_at'],'duration_ms'=>(int)$r['duration_ms'],'sql_total_ms'=>(int)$r['sql_total_ms'],'sql_count'=>(int)$r['sql_count'],'peak_mb'=>round((int)$r['peak_bytes']/1048576,2),'route'=>$r['route'],'request_type'=>$r['request_type']); }
 /** Show slowest completed PHP requests. */
 public function php($pos,$assoc) {
  list($top,$cutoff,$format)=self::options($assoc);
  $items=array_map(array(__CLASS__,'brief'),self::rows($cutoff,$top));
  self::output($items,array('id','created_at','duration_ms','sql_total_ms','peak_mb','route','request_type'),$format);
 }
 /** Show slowest stored SQL statements and callers. */
 public function sql($pos,$assoc) {
  list($top,$cutoff,$format)=self::options($assoc);$items=array();
  foreach (self::rows($cutoff) as $r) foreach ((array)(self::payload($r)['items']??array()) as $q) $items[]=array('trace_id'=>(int)$r['id'],'ms'=>(float)($q['ms']??0),'route'=>$r['route'],'sql'=>(string)($q['sql']??''),'caller'=>(string)($q['caller']??''));
  usort($items,function($a,$b){return $b['ms']<=>$a['ms'];});
  self::output(array_slice($items,0,$top),array('trace_id','ms','route','sql','caller'),$format);
 }
 /** Show recorded WordPress lifecycle checkpoints (elapsed, not exclusive hook time). */
 public function hooks($pos,$assoc) {
  list($top,$cutoff,$format)=self::options($assoc);$items=array();
  foreach (self::rows($cutoff) as $r) foreach ((array)(self::payload($r)['php_checkpoints']??array()) as $p) $items[]=array('trace_id'=>(int)$r['id'],'hook'=>(string)($p['hook']??''),'elapsed_ms'=>(float)($p['elapsed_ms']??0),'memory_mb'=>(float)($p['memory_mb']??0),'route'=>$r['route']);
  usort($items,function($a,$b){return $b['elapsed_ms']<=>$a['elapsed_ms'];});
  self::output(array_slice($items,0,$top),array('trace_id','hook','elapsed_ms','memory_mb','route'),$format);
 }
 /** Show a complete stored trace.
  *
  * ## OPTIONS
  * <id> : Numeric trace ID.
  * [--format=<format>] : json or table.
  */
 public function show($pos,$assoc) {
  if (!isset($pos[0]) || !ctype_digit((string)$pos[0]) || (int)$pos[0]<1) WP_CLI::error('Supply a positive numeric trace ID.');
  global $wpdb;$t=self::table();$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id = %d",(int)$pos[0]),ARRAY_A);
  if (!$r) WP_CLI::error('Trace not found.');
  $payload=self::payload($r);unset($r['queries']);$r['diagnostics']=$payload;
  $format=$assoc['format']??'json';
  if ($format==='json') { WP_CLI::line(wp_json_encode($r,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES));return; }
  if ($format!=='table') WP_CLI::error('--format must be table or json.');
  foreach ($r as $key=>$val) WP_CLI::line($key.': '.(is_array($val)?wp_json_encode($val,JSON_PRETTY_PRINT):$val));
 }
 /** Show slowest instrumented WordPress callbacks (inclusive time). */
 public function callbacks($pos,$assoc) {
  list($top,$cutoff,$format)=self::options($assoc);$items=array();
  foreach (self::rows($cutoff) as $r) {
   $payload=self::payload($r);
   foreach ((array)($payload['profiler']['callbacks']??array()) as $cb)
    $items[]=array('trace_id'=>(int)$r['id'],'ms'=>(float)($cb['ms']??0),'hook'=>(string)($cb['hook']??''),'callback'=>(string)($cb['callback']??''),'file'=>(string)($cb['file']??''),'route'=>$r['route']);
  }
  usort($items,function($a,$b){return $b['ms']<=>$a['ms'];});
  self::output(array_slice($items,0,$top),array('trace_id','ms','hook','callback','file','route'),$format);
 }
 /** Show slow WordPress HTTP API requests (host only; no URLs or credentials). */
 public function http($pos,$assoc) {
  list($top,$cutoff,$format)=self::options($assoc);$items=array();
  foreach (self::rows($cutoff) as $r) {
   $payload=self::payload($r);
   foreach ((array)($payload['profiler']['http_requests']??array()) as $h)
    $items[]=array('trace_id'=>(int)$r['id'],'ms'=>(float)($h['ms']??0),'host'=>(string)($h['host']??''),'status'=>(string)($h['status']??''),'route'=>$r['route']);
  }
  usort($items,function($a,$b){return $b['ms']<=>$a['ms'];});
  self::output(array_slice($items,0,$top),array('trace_id','ms','host','status','route'),$format);
 }
 /** Remove expired and excess stored traces now. */
 public function cleanup($pos,$assoc) { WST::cleanup();WP_CLI::success('Trace retention cleanup completed.'); }
}
WP_CLI::add_command('slow-trace','WST_CLI');
