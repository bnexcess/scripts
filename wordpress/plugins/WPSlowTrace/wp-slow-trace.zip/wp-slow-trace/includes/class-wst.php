<?php
if (!defined('ABSPATH')) exit;
final class WST {
 const OPT='wst_settings'; const CRON='wst_cleanup';
 private static $started=0; private static $peak=0; private static $checkpoints=array();
 public static function defaults() { return array('php_ms'=>2000,'sql_ms'=>100,'retention'=>7,'mode'=>'slow','enabled'=>1,'max_queries'=>30,'max_rows'=>10000); }
 public static function settings() { $v=get_option(self::OPT,array()); return wp_parse_args(is_array($v)?$v:array(),self::defaults()); }
 public static function activate() {
  global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php';
  $table=$wpdb->prefix.'wst_traces'; $collate=$wpdb->get_charset_collate();
  dbDelta("CREATE TABLE $table (
   id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
   created_at datetime NOT NULL,
   duration_ms int(10) unsigned NOT NULL,
   sql_total_ms int(10) unsigned NOT NULL,
   sql_count int(10) unsigned NOT NULL,
   peak_bytes bigint(20) unsigned NOT NULL,
   method varchar(12) NOT NULL,
   route varchar(255) NOT NULL,
   request_type varchar(24) NOT NULL,
   queries longtext NOT NULL,
   PRIMARY KEY  (id),
   KEY created_at (created_at),
   KEY duration_ms (duration_ms)
  ) $collate;");
  if (!get_option(self::OPT)) add_option(self::OPT,self::defaults(), '', false);
  if (!wp_next_scheduled(self::CRON)) wp_schedule_event(time()+3600,'daily',self::CRON);
 }
 public static function deactivate() { wp_clear_scheduled_hook(self::CRON); }
 public static function init() {
  $s=self::settings();
  add_action('admin_menu',array(__CLASS__,'menu'));
  add_action('admin_post_wst_save',array(__CLASS__,'save'));
  add_action('admin_post_wst_delete',array(__CLASS__,'delete'));
  add_action(self::CRON,array(__CLASS__,'cleanup'));
  if (!wp_next_scheduled(self::CRON)) wp_schedule_event(time()+3600,'daily',self::CRON);
  if (empty($s['enabled'])) return;
  self::$started=isset($GLOBALS['wst_request_started'])?(float)$GLOBALS['wst_request_started']:(isset($_SERVER['REQUEST_TIME_FLOAT'])?(float)$_SERVER['REQUEST_TIME_FLOAT']:microtime(true));
  foreach (array('init','wp_loaded','parse_request','wp','template_redirect','shutdown') as $hook) add_action($hook,function() use ($hook) { WST::checkpoint($hook); },PHP_INT_MAX);
  register_shutdown_function(array(__CLASS__,'shutdown'));
 }
 public static function checkpoint($hook) {
  if (count(self::$checkpoints)>=30) return;
  self::$checkpoints[]=array('hook'=>$hook,'elapsed_ms'=>round((microtime(true)-self::$started)*1000,2),'memory_mb'=>round(memory_get_usage(true)/1048576,2));
 }
 private static function route() {
  $path=isset($_SERVER['REQUEST_URI'])?wp_unslash($_SERVER['REQUEST_URI']):'/';
  $path=explode('?', $path,2)[0];
  $path=preg_replace('/[\x00-\x1f\x7f]/','',$path);
  return substr($path,0,255);
 }
 private static function type() {
  if (defined('DOING_CRON') && DOING_CRON) return 'cron';
  if (defined('DOING_AJAX') && DOING_AJAX) return 'ajax';
  if (defined('REST_REQUEST') && REST_REQUEST) return 'rest';
  if (is_admin()) return 'admin';
  return 'frontend';
 }
 private static function scrub($sql) {
  // Never store SQL literals, even for SELECT statements. Preserve structure only.
  $sql=preg_replace('/\x27(?:\x27\x27|\\\\.|[^\x27])*\x27|"(?:\\\\.|[^"])*"/s','?',(string)$sql);
  $sql=preg_replace('/\b(?:0x[0-9a-f]+|\d+(?:\.\d+)?)\b/i','?', $sql);
  $sql=preg_replace('/\s+/',' ', $sql);
  return substr(trim($sql),0,1500);
 }
 public static function shutdown() {
  global $wpdb;
  $s=self::settings(); if (empty($s['enabled'])) return;
  $ms=max(0,(int)round((microtime(true)-self::$started)*1000));
  if ($s['mode']==='slow' && $ms<(int)$s['php_ms']) return;
  $sqltotal=0; $count=0; $slow=array();
  if (isset($wpdb->queries) && is_array($wpdb->queries)) {
   foreach ($wpdb->queries as $q) {
    if (!isset($q[1])) continue;
    $duration=(float)$q[1]*1000; $sqltotal+=$duration; $count++;
    if ($duration >= (int)$s['sql_ms'] && count($slow)<(int)$s['max_queries']) {
     $slow[]=array('ms'=>round($duration,2),'sql'=>self::scrub(isset($q[0])?$q[0]:''),'caller'=>isset($q[2])?substr(preg_replace('/[\x00-\x1f]/',' ',(string)$q[2]),0,400):'');
    }
   }
  }
  // If SAVEQUERIES was not enabled, SQL details are unavailable, not zero queries.
  $sqlAvailable=defined('SAVEQUERIES') && SAVEQUERIES === true;
  $method=isset($_SERVER['REQUEST_METHOD'])?strtoupper((string)$_SERVER['REQUEST_METHOD']):'CLI';
  $wpdb->insert($wpdb->prefix.'wst_traces',array(
   'created_at'=>current_time('mysql',true),'duration_ms'=>$ms,
   'sql_total_ms'=>(int)round($sqltotal),'sql_count'=>$sqlAvailable?$count:0,
   'peak_bytes'=>memory_get_peak_usage(true),'method'=>substr(preg_replace('/[^A-Z]/','',$method),0,12),
   'route'=>self::route(),'request_type'=>self::type(),
   'queries'=>wp_json_encode(array('available'=>$sqlAvailable,'items'=>$slow,'php_checkpoints'=>self::$checkpoints)),
  ),array('%s','%d','%d','%d','%d','%s','%s','%s','%s'));
 }
 public static function cleanup() {
  global $wpdb; $s=self::settings(); $table=$wpdb->prefix.'wst_traces';
  $cutoff=gmdate('Y-m-d H:i:s',time()-((int)$s['retention']*DAY_IN_SECONDS));
  $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE created_at < %s",$cutoff));
  $max=(int)$s['max_rows'];
  $ids=$wpdb->get_col($wpdb->prepare("SELECT id FROM $table ORDER BY id DESC LIMIT 1 OFFSET %d",$max));
  if ($ids) $wpdb->query($wpdb->prepare("DELETE FROM $table WHERE id <= %d",(int)$ids[0]));
 }
 public static function menu() { add_management_page('WP Slow Trace','WP Slow Trace','manage_options','wp-slow-trace',array(__CLASS__,'page')); }
 public static function save() {
  if (!current_user_can('manage_options')) wp_die('Forbidden',403);
  check_admin_referer('wst_save');
  $s=self::settings();
  foreach (array('php_ms'=>array(100,600000),'sql_ms'=>array(1,60000),'retention'=>array(1,90),'max_queries'=>array(1,100),'max_rows'=>array(100,100000)) as $key=>$range) {
   $raw=isset($_POST[$key])?absint(wp_unslash($_POST[$key])):$s[$key];
   $s[$key]=max($range[0],min($range[1],$raw));
  }
  $s['enabled']=isset($_POST['enabled'])?1:0;
  $s['mode']='slow'; // v1 deliberately only persists slow requests
  update_option(self::OPT,$s,false);
  wp_safe_redirect(admin_url('tools.php?page=wp-slow-trace&saved=1'));exit;
 }
 public static function delete() {
  if (!current_user_can('manage_options')) wp_die('Forbidden',403);
  check_admin_referer('wst_delete');
  global $wpdb; $wpdb->query('DELETE FROM '.$wpdb->prefix.'wst_traces'); 
  wp_safe_redirect(admin_url('tools.php?page=wp-slow-trace&deleted=1'));exit;
 }
 public static function page() {
  if (!current_user_can('manage_options')) return;
  global $wpdb; $s=self::settings(); $table=$wpdb->prefix.'wst_traces';
  $rows=$wpdb->get_results("SELECT * FROM $table ORDER BY id DESC LIMIT 50");
  echo '<div class="wrap"><h1>WP Slow Trace</h1><p>Slow PHP requests and bounded, redacted SQL diagnostics. Times are approximate and SQL collection requires the MU bootstrap.</p>';
  if (isset($_GET['saved'])) echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
  if (isset($_GET['deleted'])) echo '<div class="notice notice-success"><p>Traces deleted.</p></div>';
  echo '<form action="'.esc_url(admin_url('admin-post.php')).'" method="post"><input type="hidden" name="action" value="wst_save">';
  wp_nonce_field('wst_save');
  echo '<table class="form-table"><tbody>';
  foreach (array('php_ms'=>'PHP threshold (ms)','sql_ms'=>'SQL threshold (ms)','retention'=>'Retention (days)','max_queries'=>'Max slow queries per trace','max_rows'=>'Max stored traces') as $key=>$label) {
   echo '<tr><th><label for="'.esc_attr($key).'">'.esc_html($label).'</label></th><td><input type="number" id="'.esc_attr($key).'" name="'.esc_attr($key).'" value="'.esc_attr($s[$key]).'"></td></tr>';
  }
  echo '<tr><th>Collection</th><td><label><input type="checkbox" name="enabled" value="1" '.checked($s['enabled'],1,false).'> Enabled (slow requests only)</label></td></tr>';
  echo '</tbody></table>';submit_button('Save settings');echo '</form>';
  echo '<h2>Recent slow requests (latest 50)</h2><table class="widefat striped"><thead><tr><th>UTC</th><th>Route</th><th>Type</th><th>PHP ms</th><th>SQL ms</th><th>SQL count</th><th>Peak MB</th><th>SQL and PHP trace details</th></tr></thead><tbody>';
  if (!$rows) echo '<tr><td colspan="8">No slow requests captured yet.</td></tr>';
  foreach ((array)$rows as $r) {
   $data=json_decode($r->queries,true);$available=is_array($data)&&!empty($data['available']);
   $details=$available?'No queries above threshold':'Unavailable (install MU bootstrap)';
   if ($available && !empty($data['items'])) {
    $parts=array();foreach ($data['items'] as $q) $parts[]=number_format((float)$q['ms'],2).' ms | '.$q['sql'].' | '.$q['caller'];
    $details=implode("\n\n",$parts);
   }
   $checkpoints=isset($data['php_checkpoints'])&&is_array($data['php_checkpoints'])?$data['php_checkpoints']:array();
   $phpDetails=array();foreach($checkpoints as $point) $phpDetails[]=($point['hook']??'hook').' at '.($point['elapsed_ms']??0).' ms ('.($point['memory_mb']??0).' MB)';
   $details.="\n\nPHP lifecycle checkpoints (elapsed since request start):\n".implode("\n",$phpDetails);
   echo '<tr><td>'.esc_html($r->created_at).'</td><td>'.esc_html($r->method.' '.$r->route).'</td><td>'.esc_html($r->request_type).'</td><td>'.esc_html($r->duration_ms).'</td><td>'.($available?esc_html($r->sql_total_ms):'N/A').'</td><td>'.($available?esc_html($r->sql_count):'N/A').'</td><td>'.esc_html(round($r->peak_bytes/1048576,1)).'</td><td><details><summary>View</summary><pre style="white-space:pre-wrap;max-width:650px">'.esc_html($details).'</pre></details></td></tr>';
  }
  echo '</tbody></table>';

  echo '<h2>Delete stored traces</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'">';
  echo '<input type="hidden" name="action" value="wst_delete">';wp_nonce_field('wst_delete');
  submit_button('Delete all traces','delete');echo '</form>';
  echo '<p><strong>PHP traces:</strong> WordPress lifecycle checkpoints are captured within the request. These are elapsed milestones, not full PHP call stacks or per-function CPU measurements. A request that never completes cannot be persisted by this plugin.</p></div>';
 }
}
