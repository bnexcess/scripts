<?php
if (!defined('ABSPATH')) exit;
/** Best-effort instrumentation of WordPress callbacks and HTTP API calls. */
final class WST_Profiler {
 private static $callbacks=array(), $http=array(), $pending=array(), $wrapped=0;
 private static $max_wrapped=2500, $max_samples=1000;
 public static function boot() {
  // 'all' executes before callbacks on the current hook. Do not profile 'all' itself.
  add_action('all',array(__CLASS__,'prepare_hook'),PHP_INT_MIN,0);
  add_filter('http_request_args',array(__CLASS__,'http_start'),PHP_INT_MAX,2);
  add_action('http_api_debug',array(__CLASS__,'http_end'),PHP_INT_MAX,5);
 }
 private static function label($fn) {
  if (is_string($fn)) return $fn;
  if ($fn instanceof Closure) return 'Closure';
  if (is_array($fn) && count($fn)===2) return (is_object($fn[0])?get_class($fn[0]):(string)$fn[0]).'::'.$fn[1];
  return 'Callable';
 }
 private static function location($fn) {
  try {
   if ($fn instanceof Closure) $r=new ReflectionFunction($fn);
   elseif (is_array($fn) && count($fn)===2) $r=new ReflectionMethod($fn[0],$fn[1]);
   elseif (is_string($fn) && strpos($fn,'::')!==false) $r=new ReflectionMethod($fn);
   elseif (is_string($fn)) $r=new ReflectionFunction($fn);
   else return '';
   $file=$r->getFileName();
   return $file ? self::path($file).':'.$r->getStartLine() : '';
  } catch (Throwable $e) { return ''; }
 }
 private static function path($file) {
  $file=str_replace('\\','/',$file);
  $root=str_replace('\\','/',ABSPATH);
  return strpos($file,$root)===0 ? substr($file,strlen($root)) : basename($file);
 }
 public static function prepare_hook() {
  global $wp_filter;
  $hook=current_filter();
  if (!$hook || $hook==='all' || empty($wp_filter[$hook]) || !($wp_filter[$hook] instanceof WP_Hook)) return;
  $obj=$wp_filter[$hook];
  foreach ($obj->callbacks as $priority=>&$group) {
   foreach ($group as $id=>&$entry) {
    if (self::$wrapped>=self::$max_wrapped) break 2;
    if (!isset($entry['function']) || !is_callable($entry['function'])) continue;
    $fn=$entry['function'];
    if ($fn instanceof WST_Profiled_Callback) continue;
    if (is_array($fn) && isset($fn[0]) && (is_object($fn[0]) ? get_class($fn[0])==='WST_Profiler' : $fn[0]==='WST_Profiler')) continue;
    $label=self::label($fn); $file=self::location($fn);
    $entry['function']=new WST_Profiled_Callback($fn,$hook,$label,$file);
    self::$wrapped++;
   }
  }
  unset($group,$entry);
 }
 public static function record($hook,$label,$file,$ms) {
  if (count(self::$callbacks)>=self::$max_samples) return;
  self::$callbacks[]=array('hook'=>substr($hook,0,100),'callback'=>substr($label,0,200),'file'=>substr($file,0,250),'ms'=>round($ms,3));
 }
 public static function http_start($args,$url) {
  $key=hash('sha256',(string)$url);
  if (!isset(self::$pending[$key])) self::$pending[$key]=array();
  self::$pending[$key][]=microtime(true);
  return $args;
 }
 public static function http_end($response,$context,$class,$args,$url) {
  if ($context!=='response') return;
  $key=hash('sha256',(string)$url);
  if (empty(self::$pending[$key])) return;
  $start=array_pop(self::$pending[$key]);
  if (count(self::$http)>=100) return;
  $host=wp_parse_url($url,PHP_URL_HOST);
  $code=is_wp_error($response)?'WP_Error':(string)wp_remote_retrieve_response_code($response);
  self::$http[]=array('host'=>is_string($host)?substr($host,0,180):'unknown','ms'=>round((microtime(true)-$start)*1000,2),'status'=>$code);
 }
 public static function export($limit=50) {
  $callbacks=self::$callbacks;
  usort($callbacks,function($a,$b){return $b['ms']<=>$a['ms'];});
  $http=self::$http;
  usort($http,function($a,$b){return $b['ms']<=>$a['ms'];});
  return array('callbacks'=>array_slice($callbacks,0,$limit),'http_requests'=>array_slice($http,0,30),
   'callback_samples'=>count(self::$callbacks),'callback_limit_reached'=>count(self::$callbacks)>=self::$max_samples,
   'wrapped_callbacks'=>self::$wrapped,'http_samples'=>count(self::$http));
 }
}
/** Wrapper preserves the original callable's accepted arguments and return value. */
final class WST_Profiled_Callback {
 private $original,$hook,$label,$file;
 public function __construct($fn,$hook,$label,$file) {$this->original=$fn;$this->hook=$hook;$this->label=$label;$this->file=$file;}
 public function __invoke(...$args) {
  $start=microtime(true);
  try { return call_user_func_array($this->original,$args); }
  finally { WST_Profiler::record($this->hook,$this->label,$this->file,(microtime(true)-$start)*1000); }
 }
}
