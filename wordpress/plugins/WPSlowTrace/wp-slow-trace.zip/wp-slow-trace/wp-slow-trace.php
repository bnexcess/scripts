<?php
/**
 * Plugin Name: WP Slow Trace
 * Description: Bounded, administrator-only slow PHP and SQL request tracing.
 * Version: 1.3.0
 * Requires PHP: 7.4
 */
if (!defined('ABSPATH')) exit;
define('WST_VERSION','1.3.0');
define('WST_PATH',plugin_dir_path(__FILE__));
require_once WST_PATH.'includes/class-wst.php';
register_activation_hook(__FILE__,array('WST','activate'));
register_deactivation_hook(__FILE__,array('WST','deactivate'));
add_action('plugins_loaded',array('WST','init'),1);


if (defined('WP_CLI') && WP_CLI) require_once WST_PATH.'includes/class-wst-cli.php';
